
Ethuebung Compiler
==================

An small application is available that will help you compile directly exercise
sheets, solution sheets and tips sheets. The source code of this application is
here. You probably want to download a ready-to-use binary version:

    https://github.com/phfaist/ethuebung/releases/


If you wish to not download the (big) binary, you may run the python application
directly. You will in this case need the PyQt4 python package. After downloading
or cloning this repository, you can run this helper application as:

    python guicompiler.py


