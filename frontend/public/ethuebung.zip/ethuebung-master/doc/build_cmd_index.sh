#!/bin/bash
sort -f <doc_ethuebung.pkgdef >doc_ethuebung.pkgdefsorted
